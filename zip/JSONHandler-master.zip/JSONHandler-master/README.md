# Example JSON Handler iOS app

An example of parsing a JSON file and displaying the data in a table view.

Requires Xcode 5 and iOS 7.


***
[Dada Beatnik](http://www.dadabeatnik.com)
