//
//  MapAnnotation.m
//  YouthHostelsLombardy
//
//  Created by pierangelo on 19/05/15.
//  Copyright (c) 2015 pierangelo. All rights reserved.
//

#import "MapAnnotation.h"

@implementation MapAnnotation

@end
